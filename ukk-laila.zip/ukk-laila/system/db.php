<?php

// ganti 'kasir_test' jadi nama database kalian
$db = mysqli_connect('localhost', 'root', '', 'kasir_nissa');