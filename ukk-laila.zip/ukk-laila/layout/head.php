<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Aplikasi Kasir' ?></title>
    <link rel="stylesheet" href="<?= uri('/assets/css/bootstrap.min.css') ?>">
    <script src="<?= uri('/assets/js/bootstrap.min.js') ?>"></script>
</head>

<body>