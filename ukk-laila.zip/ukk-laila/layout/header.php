<?php

require __DIR__ . '/head.php';
require __DIR__ . '/nav.php';
require __DIR__ . '/flash.php';